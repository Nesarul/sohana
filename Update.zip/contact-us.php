    <?php require_once $_SERVER['DOCUMENT_ROOT']."/"."inc/header.php";  ?>
    <script>
        $("title").html("Yachts.com - Contact Us");
        $("meta[name='description']").attr("content", "Contact Us");
        $("meta[name='keywords']").attr("content", "Contact Us");
    </script>
    <div class="container">
        <div class="row py-5">
            <div class="col-12">
                <h2 class="text-start mb-3">Contact Us</h2>

                <div class="card mb-3 w-100">
                    <div class="card-body">
                    <h5>We are available 7 days a week at eric@yachts.com </h5>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <?php require_once('./inc/footer.php'); ?>